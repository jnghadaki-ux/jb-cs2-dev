SWBS prisoners on CS2's agent skeleton
======================================

UPDATE (fix for players lying flat inside the floor)
---------------------------------------------------
The body mesh is now a .dmx file (Z-up, written into a copy of Valve's diver body .dmx) instead of an .smd.
The model compiler treated the .smd as a different axis system from the diver skeleton, so the body was rotated
against the bones and in game the player lay flat inside the floor. When you copy this "characters" folder over
your addon content, also DELETE the old .smd file in each model folder (the .vmdl now points at the .dmx).

Fixes the console flood "Attempted to attach attachment ... to an unknown bone" and prisoners not holding weapons
properly. Each prisoner is rebuilt on the skeleton of CS2's own diver agent (86 bones, current animations) with that
agent's hitboxes, ragdoll and attachments. First-person arms are the diver's gloves and sleeves.

Install (Windows, CS2 Workshop Tools):
 1. Copy the "characters" folder from this zip into your pack's addon content folder
    (...\Counter-Strike Global Offensive\content\csgo_addons\swbs_jailbreak\), replacing the three prisoner folders.
 2. Run compile_pack.bat as before and update the Workshop item.
 3. Check them before going live: open one in the Workshop Tools model viewer (it should play the CS2 animations),
    or try it on a local test server.
 4. In the plugin config (PlayerModels): ApplyModels = true, AllowPackPrisonerModels = true and PrisonerModels =
      characters/models/swbs/prisoners/male_black_big/male_black_big.vmdl
      characters/models/swbs/prisoners/female_asian/female_asian.vmdl
      characters/models/swbs/prisoners/male_white_hair/male_white_hair.vmdl
    Guards keep their own CS2 agent (old characters/models/ctm_* paths are skipped automatically).
