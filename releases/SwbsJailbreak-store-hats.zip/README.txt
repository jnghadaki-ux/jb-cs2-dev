SWBS store hats for the workshop pack
=====================================

Six hats for the !store Hats category: top hat, gold crown, party hat, halo, red beanie and cowboy hat. They share one
white material; the plugin tints each store item (so one model can be sold in several colours by adding store items).

Install (Windows, CS2 Workshop Tools):
 1. Copy the "swbs_jailbreak" folder from this zip over your workshop pack folder (it only adds models/swbs/hats and
    materials/swbs/hats, nothing is replaced).
 2. Run compile_pack.bat as usual (it compiles everything under models/swbs/ and materials/swbs/) and update the
    pack's Workshop item.
 3. Plugin config: WorkshopPack.HatModels = true, then reload the plugin. The Hats category appears in !store.
    Hats sit on the head attachment "clip_limit" (Store.HatAttachment); Store.HatHeight moves them up or down.
