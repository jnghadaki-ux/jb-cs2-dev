SWBS store pack (part 2, KOTOR) on CS2's agent skeleton
=======================================================

Fixes store player models making players invisible. The old models had no worldmodel animation skeleton, no
root_motion root bone and no first_or_third_person body group, so CS2 could not pose or show them. Each character is
rebuilt on the skeleton of CS2's own diver agent (86 bones, current animations) with that agent's hitboxes, ragdoll,
attachments and body groups. Materials are unchanged. First-person arms are the diver's gloves and sleeves.

Install (Windows, CS2 Workshop Tools):
 1. Copy the "characters" folder from this zip into the store pack's addon content folder
    (...\Counter-Strike Global Offensive\content\csgo_addons\swbs_store\), replacing the 7 kotor_* folders.
 2. Compile the store pack as before and update its Workshop item.
 3. Check one in the Workshop Tools model viewer (it should play the CS2 animations) or on a test server.
 4. Plugin config: WorkshopPack.StoreModels = true (the store items keep the same paths). Reload the plugin.

Deadpool (X-Force) and the Flash are in part 1 of the store pack and still need the same rebuild.
