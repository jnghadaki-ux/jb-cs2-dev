SWBS store pack player models on CS2's agent skeleton (all 9)
=============================================================

UPDATE (fix for players lying flat inside the floor)
---------------------------------------------------
The body mesh is now a .dmx file (Z-up, written into a copy of Valve's diver body .dmx) instead of an .smd.
The model compiler treated the .smd as a different axis system from the diver skeleton, so the body was rotated
against the bones and in game the player lay flat inside the floor. When you copy this "characters" folder over
your addon content, also DELETE the old .smd file in each model folder (the .vmdl now points at the .dmx).

Fixes store player models making players invisible. The old models had no worldmodel animation skeleton, no
root_motion root bone and no first_or_third_person body group, so CS2 could not pose or show them. Each character is
rebuilt on the skeleton of CS2's own diver agent (86 bones, current animations) with that agent's hitboxes, ragdoll,
attachments and body groups. Materials are unchanged. First-person arms are the diver's gloves and sleeves.

Models: deadpool_xforce, flash, kotor_malak, kotor_nihilus, kotor_revan, kotor_sion, kotor_sith_trooper,
kotor_sith_trooper_red, kotor_traya.

Install (Windows, CS2 Workshop Tools):
 1. Copy the "characters" folder from this zip into the store pack's addon content folder
    (...\Counter-Strike Global Offensive\content\csgo_addons\swbs_store\), replacing the 9 character folders.
    The old characters/models/swbs/store/cs2_bind_pose.smd is no longer used (you can delete it).
 2. Run compile_pack.bat for the store pack and update its Workshop item.
 3. Check one in the Workshop Tools model viewer (it should play the CS2 animations) or on a test server.
 4. Plugin config: WorkshopPack.StoreModels = true (the store items keep the same paths). Reload the plugin.
