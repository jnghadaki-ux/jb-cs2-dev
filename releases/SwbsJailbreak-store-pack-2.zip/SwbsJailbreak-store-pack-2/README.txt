SWBS store pack 2
=================

Brings back the SMPlugins store's equipment slots that the CS2 port did not have yet ("Item_Equipment" face and torso):

  Face (!store > Face)                          Back (!store > Back)
    models/swbs/store2/face/sunglasses             models/swbs/store2/back/angel_wings
    models/swbs/store2/face/round_glasses          models/swbs/store2/back/bat_wings     (sold as Devil wings)
    models/swbs/store2/face/bandit_mask            models/swbs/store2/back/jetpack
    models/swbs/store2/face/mustache               models/swbs/store2/back/backpack
    models/swbs/store2/face/clown_nose             models/swbs/store2/back/katana
    models/swbs/store2/face/eyepatch

They share one white material; the plugin tints each store item, so one model can be sold in several colours by adding
store items (copy an item in the Store config, give it a new Id, Name and Color).

Install (Windows)
-----------------
1. Extract the whole zip, then double click compile_pack.bat. It finds CS2, copies swbs_store2 into
   ...\Counter-Strike Global Offensive\content\csgo_addons\swbs_store2\ and compiles it.
   (Or copy the swbs_store2 folder there yourself and compile in the Workshop Tools: Asset Browser, search swbs,
   select everything, right click - Recompile.)
2. Workshop Tools - pick swbs_store2 - Workshop Manager - upload it as a NEW item (keep it separate from the main pack
   and from the first store pack).
3. Server: add its id to MultiAddonManager after the other two packs:
     mm_extra_addons "<main pack id>,<store pack id>,<store pack 2 id>"
4. Plugin config, section WorkshopPack: "Store2Equipment": true (and "Store2WorkshopId" for your reference). Reload the
   plugin. The Face and Back categories appear in !store.

Tuning (section Store)
----------------------
  FaceAttachment "clip_limit", FaceForward 4.5, FaceHeight 0    glasses and masks follow the head
  BackAttachment "c4", BackBelowEye 17, BackDepth 6               wings and packs follow the upper spine
If glasses sink into a model's face raise FaceForward; if a back item floats behind the player lower BackDepth.
Equipment is hidden from its wearer, honours !store > Effect visibility and is off on wardays and in non-freeday LRs.
