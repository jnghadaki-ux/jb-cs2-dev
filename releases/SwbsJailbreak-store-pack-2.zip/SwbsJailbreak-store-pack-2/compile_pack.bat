@echo off
setlocal EnableExtensions
title SWBS store pack 2 - compile
rem Finds CS2 (any Steam library) and its resource compiler, copies the pack into content\csgo_addons\swbs_store2,
rem compiles it and checks the result. Optional: drag your "Counter-Strike Global Offensive" folder onto this file.
set "PACK=%~dp0"
set "LOG=%PACK%compile_log.txt"
echo ============================================
echo  SWBS store pack 2 - compile
echo ============================================
echo Running from: %PACK%
echo.
if not exist "%PACK%find_cs2.ps1" goto :not_extracted

echo Looking for Counter-Strike 2 and the Workshop Tools compiler (can take a few seconds)...
set "CS2="
set "RC="
for /f "usebackq tokens=1,* delims==" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PACK%find_cs2.ps1" "%~1"`) do set "%%A=%%B"
if "%CS2%"=="" goto :no_cs2
set "DEST=%CS2%\content\csgo_addons\swbs_store2"
set "OUT=%CS2%\game\csgo_addons\swbs_store2"
echo   CS2 folder: %CS2%
if not "%RC%"=="" echo   Compiler:   %RC%
if "%RC%"=="" echo   Compiler:   not found in this CS2 folder
echo.

rem The pack's swbs_store2 folder: next to this file, one folder down (zip extracted into a folder of the same
rem name), or already copied into CS2's content folder by hand.
set "SRC="
if exist "%PACK%swbs_store2\materials\swbs\store2\equip_white.vmat" set "SRC=%PACK%swbs_store2"
if "%SRC%"=="" if exist "%PACK%SwbsJailbreak-store-pack-2\swbs_store2\materials\swbs\store2\equip_white.vmat" set "SRC=%PACK%SwbsJailbreak-store-pack-2\swbs_store2"
if "%SRC%"=="" if exist "%DEST%\materials\swbs\store2\equip_white.vmat" goto :already_copied
if "%SRC%"=="" goto :no_source

echo [1/3] Copying the pack into
echo       %DEST%
robocopy "%SRC%" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto :copy_failed
goto :compile

:already_copied
echo [1/3] The pack is already in
echo       %DEST%
echo       (no swbs_store2 folder next to this file, so using those files)

:compile
if "%RC%"=="" goto :no_compiler
rem Only the pack's own files: the example maps a new addon starts with are left alone (building them needs a
rem lightmap-capable GPU and is not part of the pack).
echo [2/3] Compiling the pack (output in compile_log.txt; player models take a minute)...
> "%LOG%" echo SWBS store pack 2 compile log
echo === materials >> "%LOG%"
"%RC%" -r -i "%DEST%\materials\swbs\store2\*.vmat" >> "%LOG%" 2>&1
echo === equipment >> "%LOG%"
"%RC%" -r -i "%DEST%\models\swbs\store2\*.vmdl" >> "%LOG%" 2>&1
:check
echo [3/3] Checking the result...
rem Some setups write compiled files next to the sources (content); the Workshop upload takes them from game.
if not exist "%OUT%" mkdir "%OUT%"
robocopy "%DEST%" "%OUT%" *.vmdl_c *.vmat_c *.vtex_c *.vsnd_c *.vsndevts_c /S /XO /NFL /NDL /NJH /NJS /NP >nul
if not exist "%OUT%\materials\swbs\store2\equip_white.vmat_c" goto :compile_failed
set /a N=0
if exist "%OUT%\sounds" for /r "%OUT%\sounds" %%F in (*.vsnd_c) do set /a N+=1
set /a M=0
for %%G in (models\swbs\store2\face\sunglasses models\swbs\store2\face\round_glasses models\swbs\store2\face\bandit_mask models\swbs\store2\face\mustache models\swbs\store2\face\clown_nose models\swbs\store2\face\eyepatch models\swbs\store2\back\angel_wings models\swbs\store2\back\bat_wings models\swbs\store2\back\jetpack models\swbs\store2\back\backpack models\swbs\store2\back\katana) do if exist "%OUT%\%%G.vmdl_c" (set /a M+=1) else (echo   missing model: %%G)
echo.
echo SUCCESS: %M% of 11 models are compiled in
echo   %OUT%
if %M% LSS 11 echo NOTE: not every model compiled. The compiler's messages about them:
if %M% LSS 11 if exist "%LOG%" findstr /i /c:"error" /c:"warning" /c:"fail" "%LOG%"
if %M% LSS 11 echo Send compile_log.txt. Keep WorkshopPack.Store2Equipment off until every model compiles.
echo.
echo Next: start the CS2 Workshop Tools, pick the swbs_store2 addon and upload it with the
echo Workshop Manager (README.txt).
goto :end

:no_compiler
if exist "%OUT%\materials\swbs\store2\equip_white.vmat_c" goto :check
echo.
echo The files are copied. This CS2 folder has no resourcecompiler.exe, so compile inside the Workshop Tools:
echo   1. Steam - Counter-Strike 2 - Play - "Launch Counter-Strike 2 Workshop Tools".
echo   2. In the launcher pick swbs_store2 and click Launch Tools.
echo   3. In the Asset Browser type swbs in the search box, select everything it lists,
echo      right click - Recompile (or Full Recompile).
echo   4. Run compile_pack.bat again: it says SUCCESS once the compiled files are there.
goto :end

:not_extracted
echo PROBLEM: find_cs2.ps1 is not next to compile_pack.bat.
if not "%PACK:\Temp\=%"=="%PACK%" echo It looks like compile_pack.bat was opened from INSIDE the zip (Windows unpacks only that file).
echo Right click the zip - Extract All - Extract, then open the extracted folder and run compile_pack.bat there.
echo The folder you run it from must contain: compile_pack.bat, find_cs2.ps1 and the swbs_store2 folder.
goto :end

:no_source
echo PROBLEM: the swbs_store2 folder is not next to compile_pack.bat and not in
echo   %DEST%
echo These are the files next to compile_pack.bat:
dir /b "%PACK%"
echo.
echo Extract the WHOLE zip again (right click the zip - Extract All) and run compile_pack.bat from the extracted folder.
goto :end

:no_cs2
echo PROBLEM: Counter-Strike 2 was not found in your Steam libraries.
echo Drag your "Counter-Strike Global Offensive" folder onto compile_pack.bat, or run in a command prompt:
echo   compile_pack.bat "D:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive"
goto :end

:copy_failed
echo PROBLEM: could not copy the files into %DEST%
echo Close the Workshop Tools / CS2 and try again, or copy the folder contents by hand (README).
goto :end

:compile_failed
echo PROBLEM: compiling did not produce %OUT%\materials\swbs\store2\equip_white.vmat_c
if exist "%LOG%" echo The compiler said:
if exist "%LOG%" echo --------------------------------------------
if exist "%LOG%" type "%LOG%"
if exist "%LOG%" echo --------------------------------------------
echo Send compile_log.txt (next to this file) if you need help. You can also compile in the Workshop Tools:
echo Asset Browser - search swbs - select everything - right click - Recompile, then run this again.
goto :end

:end
echo.
echo Press any key to close this window.
pause >nul
