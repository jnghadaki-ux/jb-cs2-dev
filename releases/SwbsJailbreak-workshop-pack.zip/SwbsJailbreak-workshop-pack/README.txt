SWBS Jailbreak workshop pack
============================

What is in it
-------------
Sounds from the original SWBS jailbreak (SMPlugins fork), one sound event each:

  swbs.guards_win      guards win the round          -> Settings.GuardsWinSound
  swbs.prisoners_win   prisoners win the round       -> Settings.PrisonersWinSound
  swbs.lr_activated    last request activated        -> LastRequest.ActivatedSound
  swbs.freekill        !freekill report              -> Commands.FreekillSound
  swbs.chat_alert      guard message (!ctmessage)    -> Commands.GuardMessageSound
  swbs.cowbell         Horror Movie moving prisoner  -> DaysLarge.HorrorMoveSound, store kill sound "Cowbell"
  swbs.rpg_shoot       RPG / Rocketeer rocket        -> Rpg.ShootSound
  swbs.rpg_explode     rocket explosion (4 random)   -> Rpg.ExplosionSound
  swbs.rpg_pain        hurt by a rocket (2 random)   -> Rpg.PainSound
  swbs.rpg_death       killed by a rocket            -> Rpg.DeathSound
  swbs.jetpack         flying with a jetpack         -> GameDays.JetpackSound
  swbs.slap            admin slap, last guard slap   -> Admin.SlapSound, LastGuard.SlapSound
  swbs.teleport        Teleport freeday, Teleporter  -> DaysNew.TeleportSound, LastRequestsExtra.TeleporterSound

You do not type these anywhere: turning WorkshopPack.Enabled on (step 6) sets all of them once.

Models (the original SWBS props, converted to CS2: SMD mesh + PNG textures + .vmat + .vmdl):

  models/swbs/flag.vmdl            Capture the Flag flag (tinted in the team colour)
  models/swbs/capture_point.vmdl   Capture the Flag capture point
  models/swbs/finish_line.vmdl     Race LR and Speedrun finish line
  models/swbs/missile.vmdl         RPG day / Rocketeer rockets
  models/swbs/rocket_launcher.vmdl converted for later (CS2 cannot swap the knife's first-person model)

With WorkshopPack.Enabled and WorkshopPack.UseModels (default true) the plugin uses them instead of the beam versions.
If compile_pack.bat reports missing prop models, send compile_log.txt and set "UseModels": false meanwhile (a missing
model would show as the engine's error model).

Player models (the SWBS prisoners, moved onto CS2's current player skeleton with CS2's hitboxes, ragdoll and animations;
material group "white" is the white uniform):

  characters/models/swbs/prisoners/male_black_big/male_black_big.vmdl
  characters/models/swbs/prisoners/female_asian/female_asian.vmdl
  characters/models/swbs/prisoners/male_white_hair/male_white_hair.vmdl

The SWBS guard was Valve's CS:GO SWAT model; CS2 ships its own agents, so guards keep PlayerModels.GuardModel.
Check the prisoners before using them (step 7). The plugin's PlayerModels.PrisonerModels already lists them; they are
only applied with PlayerModels.ApplyModels = true.

Not included: the SpeedRuns announcer lines (clips from other games, which get Workshop items taken down), the map vote
and Blocks sounds (plugins you do not run).

The SMPlugins fork has no license file. Keep the Workshop item Unlisted and replace anything you are unsure about over time.

Steps (Windows)
---------------
1. Install the tools: Steam > Counter-Strike 2 > right click > Properties > DLC > tick "Counter-Strike 2 Workshop Tools".

2. Create the addon: start CS2 Workshop Tools (Steam > CS2 > Play > "Launch CS2 Workshop Tools"), choose
   "Create New Addon", name it exactly   swbs_jailbreak   and close the tools again.
   This makes  ...\Counter-Strike Global Offensive\content\csgo_addons\swbs_jailbreak\
   and         ...\Counter-Strike Global Offensive\game\csgo_addons\swbs_jailbreak\

3. Extract the whole zip, then double click compile_pack.bat. It finds CS2 in any Steam library, copies the pack into
   content\csgo_addons\swbs_jailbreak, compiles it and tells you SUCCESS (with the number of sounds) or what is wrong.
   If it cannot find CS2, drag your "Counter-Strike Global Offensive" folder onto compile_pack.bat.
   (By hand instead: copy the contents of this pack's swbs_jailbreak folder into
   ...\Counter-Strike Global Offensive\content\csgo_addons\swbs_jailbreak\ and in the Workshop Tools Asset Browser
   select the addon's files > right click > Recompile.)
   The compiled .vsnd_c / .vsndevts_c files appear under ...\game\csgo_addons\swbs_jailbreak\

   Quick check before uploading: in the Workshop Tools, open the Asset Browser, find swbs_jailbreak.vsndevts,
   double click a sound event and press play.

4. Upload: in the Workshop Tools open the Workshop Manager (Tools menu / the Steam Workshop button), "New", pick the
   swbs_jailbreak addon, give it a title, use this pack's preview.png, publish.
   Then on the Steam Workshop page of the item set Visibility to "Unlisted" (players must be able to download it;
   "Hidden" items do not download). Note the item id (the number in the page URL ...?id=1234567890).

5. Server: install the Metamod plugin MultiAddonManager (github.com/Source2ZE/MultiAddonManager) and in
   game/csgo/cfg/multiaddonmanager/multiaddonmanager.cfg set
       mm_extra_addons "1234567890"
   (your id; several ids are comma separated). Players download the pack when they join.

6. Plugin: in addons/counterstrikesharp/configs/plugins/SwbsJailbreak/SwbsJailbreak.json set
       "WorkshopPack": { "Enabled": true, "WorkshopId": "1234567890", ... }
   and restart the server (or change map). On the first start the plugin precaches soundevents/swbs_jailbreak.vsndevts
   and points every sound setting listed above at the pack. You can still change any of them; the console command
   css_workshoppack (root admins) points them at the pack again.

7. Player models: in the Workshop Tools Asset Browser search "prisoners", double click a model. The Model Editor
   (ModelDoc) shows it standing; in its Animation panel pick any animation (e.g. a run) and check that arms, legs
   and head move with the body. Then on the server set "PlayerModels": { "ApplyModels": true } and change map.
   If a model looks broken, set ApplyModels back to false and send a screenshot.

Updating the pack later: change files in content\csgo_addons\swbs_jailbreak, compile, Workshop Manager > your item >
Update. MultiAddonManager makes players download the new version.
