@echo off
rem Compiles the swbs_jailbreak addon with CS2's resource compiler.
rem Usage: compile_pack.bat ["path to Counter-Strike Global Offensive"]
setlocal
set "CS2=%~1"
if "%CS2%"=="" set "CS2=C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive"
set "RC=%CS2%\game\bin\win64\resourcecompiler.exe"
set "ADDON=%CS2%\content\csgo_addons\swbs_jailbreak"
if not exist "%RC%" (
  echo resourcecompiler.exe not found at "%RC%".
  echo Install "Counter-Strike 2 Workshop Tools" ^(Steam - CS2 - Properties - DLC^) or pass your CS2 folder as the first argument.
  pause
  exit /b 1
)
if not exist "%ADDON%\soundevents\swbs_jailbreak.vsndevts" (
  echo Copy the swbs_jailbreak folder from the pack into "%CS2%\content\csgo_addons\" first.
  pause
  exit /b 1
)
"%RC%" -r -i "%ADDON%\*"
echo.
echo Done. Compiled files are in "%CS2%\game\csgo_addons\swbs_jailbreak". Next: upload with the Workshop Manager (README step 4).
pause
