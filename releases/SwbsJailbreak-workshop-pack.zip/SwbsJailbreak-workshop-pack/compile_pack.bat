@echo off
setlocal EnableExtensions
title SWBS workshop pack - compile
rem Finds CS2 (any Steam library), copies the pack into content\csgo_addons\swbs_jailbreak, compiles it with CS2's
rem resourcecompiler and checks the result. Optional: drag your "Counter-Strike Global Offensive" folder onto this file.
set "PACK=%~dp0"
set "SRC=%PACK%swbs_jailbreak"
set "LOG=%PACK%compile_log.txt"
echo ============================================
echo  SWBS workshop pack - compile
echo ============================================
echo.
if not exist "%SRC%\soundevents\swbs_jailbreak.vsndevts" goto :not_extracted

set "CS2=%~1"
if not "%CS2%"=="" goto :have_cs2
echo Looking for Counter-Strike 2 in your Steam libraries...
for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%PACK%find_cs2.ps1"`) do set "CS2=%%P"
if "%CS2%"=="" goto :no_cs2
if "%CS2:~0,8%"=="NOTOOLS#" goto :no_tools_found

:have_cs2
set "RC=%CS2%\game\bin\win64\resourcecompiler.exe"
if not exist "%RC%" goto :no_tools
set "DEST=%CS2%\content\csgo_addons\swbs_jailbreak"
set "OUT=%CS2%\game\csgo_addons\swbs_jailbreak"
echo CS2 folder: %CS2%
echo.
echo [1/3] Copying the pack into
echo       %DEST%
robocopy "%SRC%" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto :copy_failed

echo [2/3] Compiling (takes a few seconds, the log goes to compile_log.txt)...
"%RC%" -r -i "%DEST%\*" > "%LOG%" 2>&1

echo [3/3] Checking the result...
if not exist "%OUT%\soundevents\swbs_jailbreak.vsndevts_c" goto :compile_failed
set /a N=0
for /r "%OUT%\sounds" %%F in (*.vsnd_c) do set /a N+=1
echo.
echo SUCCESS: the sound events and %N% sounds are compiled in
echo   %OUT%
echo.
echo Next: start the CS2 Workshop Tools, pick the swbs_jailbreak addon and upload it with the
echo Workshop Manager (README.txt step 4).
goto :end

:not_extracted
echo PROBLEM: the swbs_jailbreak folder is not next to this file.
echo Extract the WHOLE zip first (right click the zip - Extract All), then run compile_pack.bat
echo from the extracted folder. Running it from inside the zip does not work.
goto :end

:no_cs2
echo PROBLEM: Counter-Strike 2 was not found in your Steam libraries.
echo Drag your "Counter-Strike Global Offensive" folder onto compile_pack.bat, or run in a command prompt:
echo   compile_pack.bat "D:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive"
goto :end

:no_tools_found
set "CS2=%CS2:~8%"
:no_tools
echo PROBLEM: CS2 was found but the Workshop Tools are not installed:
echo   %CS2%\game\bin\win64\resourcecompiler.exe is missing.
echo Steam - right click Counter-Strike 2 - Properties - DLC - tick "Counter-Strike 2 Workshop Tools",
echo wait for the download, then run this again.
goto :end

:copy_failed
echo PROBLEM: could not copy the files into %DEST%
echo Close the Workshop Tools / CS2 and try again, or copy the folder contents by hand (README step 3).
goto :end

:compile_failed
echo PROBLEM: compiling did not produce the sound events. The compiler said:
echo --------------------------------------------
type "%LOG%"
echo --------------------------------------------
echo Send compile_log.txt (next to this file) if you need help. You can also compile in the Workshop Tools:
echo Asset Browser - swbs_jailbreak addon - select the files - right click - Recompile.
goto :end

:end
echo.
echo Press any key to close this window.
pause >nul
