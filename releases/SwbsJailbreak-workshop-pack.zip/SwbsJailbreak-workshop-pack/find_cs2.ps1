# Prints the Counter-Strike 2 install folder that has the Workshop Tools (resourcecompiler.exe), searching every
# Steam library. Prints "NOTOOLS#<folder>" when CS2 is installed without the tools. Used by compile_pack.bat.
$ErrorActionPreference = 'SilentlyContinue'
$libs = @()
foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
    $item = Get-ItemProperty $key
    if ($item.SteamPath) { $libs += $item.SteamPath }
    if ($item.InstallPath) { $libs += $item.InstallPath }
}
$libs += 'C:\Program Files (x86)\Steam'
foreach ($s in @($libs)) {
    $vdf = Join-Path ($s -replace '/', '\') 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs += $m.Groups[1].Value.Replace('\\', '\') }
    }
}
$games = $libs | ForEach-Object { Join-Path ($_ -replace '/', '\') 'steamapps\common\Counter-Strike Global Offensive' } | Select-Object -Unique
foreach ($g in $games) { if (Test-Path (Join-Path $g 'game\bin\win64\resourcecompiler.exe')) { Write-Output $g; exit 0 } }
foreach ($g in $games) { if (Test-Path (Join-Path $g 'game\bin\win64\cs2.exe')) { Write-Output ('NOTOOLS#' + $g); exit 0 } }
exit 1
