@echo off
setlocal
title SWBS Jailbreak Pack - Workshop upload
rem Uploads the compiled pack to the Steam Workshop without the CS2 Workshop Tools (SteamCMD, no GPU needed).
rem Run compile_pack.bat first. Optional: drag your "Counter-Strike Global Offensive" folder onto this file.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0upload_workshop.ps1" -Addon "swbs_jailbreak" -Title "SWBS Jailbreak Pack" -Description "Sounds, props, paintballs, trails and prisoner models for the SWBS Jailbreak server." -Cs2 "%~1"
echo.
echo Press any key to close this window.
pause >nul
